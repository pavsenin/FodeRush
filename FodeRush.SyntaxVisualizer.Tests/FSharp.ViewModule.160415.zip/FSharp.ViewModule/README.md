[![Issue Stats](http://issuestats.com/github/fsprojects/FSharp.ViewModule/badge/issue)](http://issuestats.com/github/fsprojects/FSharp.ViewModule)
[![Issue Stats](http://issuestats.com/github/fsprojects/FSharp.ViewModule/badge/pr)](http://issuestats.com/github/fsprojects/FSharp.ViewModule)

FSharp.ViewModule [![NuGet Status](http://img.shields.io/nuget/v/FSharp.ViewModule.Core.svg?style=flat)](https://www.nuget.org/packages/FSharp.ViewModule.Core/)
=================

Library providing MVVM and INotifyPropertyChanged support for F# projects

## Maintainer(s)

- [@ReedCopsey](https://github.com/ReedCopsey)

The default maintainer account for projects under "fsprojects" is [@fsprojectsgit](https://github.com/fsprojectsgit) - F# Community Project Incubation Space (repo management)
