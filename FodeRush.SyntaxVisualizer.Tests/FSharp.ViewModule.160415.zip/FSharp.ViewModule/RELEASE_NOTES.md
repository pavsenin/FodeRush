#### 0.9.9.2 - December 10 2015
* Removed type provider
* Moved to ProjectScaffold for new structure and build system
